package com.java.Employ.model;

public enum Gender {
    MALE, FEMALE;
}
