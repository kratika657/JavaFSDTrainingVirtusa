package com.java.Employ.exception;

public class EmployException extends Exception{
    public EmployException() {
    }
    public EmployException(String message) {
        super(message);
    }
}
