package com.java.spr.banksimulatorproject_phase1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankSimulatorProjectPhase1Application {

    public static void main(String[] args) {
        SpringApplication.run(BankSimulatorProjectPhase1Application.class, args);
    }

}
